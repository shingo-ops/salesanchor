from pathlib import Path
import subprocess,json,time
root=Path('/Users/tanizawashingo/worktrees/salesanchor/release-frontend-shared-button-migration/frontend')
out=Path(__file__).parent
commands=[('eslint',['npx','--no-install','eslint','--max-warnings=0']+['src/components/'+x for x in ['ConfirmModal.tsx','PriorityScoreOverride.tsx','OrderFinancialPanel.tsx','PurchaseDetailPanel.tsx','ShippingDetailPanel.tsx','SharedButtonMigration.test.tsx']]),('coverage',['npm','run','test:coverage']),('checkall',['npm','run','check:all']),('build',['npm','run','build']),('storybook',['npm','run','build-storybook'])]
results=[]
for name,cmd in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f: r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2),'log':str(out/(name+'.log'))})
 (out/'quality.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(results[-1]),flush=True)
