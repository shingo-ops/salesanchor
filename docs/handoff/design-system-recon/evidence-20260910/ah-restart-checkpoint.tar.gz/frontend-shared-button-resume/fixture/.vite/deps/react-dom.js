import { t as require_react_dom } from "./react-dom-yighAVO9.js";
export default require_react_dom();
