import { t as require_react } from "./react-DIIWqC3u.js";
export default require_react();
