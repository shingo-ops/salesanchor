import { n as __commonJSMin } from "./react-DIIWqC3u.js";
import { t as require_react_dom } from "./react-dom-yighAVO9.js";
//#region frontend/node_modules/react-dom/client.js
var require_client = /* @__PURE__ */ __commonJSMin(((exports) => {
	var m = require_react_dom();
	var i = m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
	exports.createRoot = function(c, o) {
		i.usingClientEntryPoint = true;
		try {
			return m.createRoot(c, o);
		} finally {
			i.usingClientEntryPoint = false;
		}
	};
	exports.hydrateRoot = function(c, h, o) {
		i.usingClientEntryPoint = true;
		try {
			return m.hydrateRoot(c, h, o);
		} finally {
			i.usingClientEntryPoint = false;
		}
	};
}));
//#endregion
export default require_client();

//# sourceMappingURL=react-dom_client.js.map