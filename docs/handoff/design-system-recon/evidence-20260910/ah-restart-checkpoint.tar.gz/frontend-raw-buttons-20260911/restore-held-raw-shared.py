from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd()
assert root.name=='release-frontend-shared-button-migration'
held=Path('/tmp/frontend-raw-buttons-20260911/held-raw-shared')
m=json.loads((held/'manifest.json').read_text())
for name,digest in m['files'].items():
    assert hashlib.sha256((held/name).read_bytes()).hexdigest()==digest,name
    dest=root/'frontend/src/components'/name
    if name!='SharedButtonMigration.test.tsx':
        before=subprocess.check_output(['git','show',m['base']+':frontend/src/components/'+name])
        assert dest.read_bytes()==before,name
    else:
        assert not dest.exists(),name
for name in m['files']:
    (root/'frontend/src/components'/name).write_bytes((held/name).read_bytes())
print('Restored 7/7 verified draft files; behavior verification remains pending')
