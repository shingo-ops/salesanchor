# AH resumed test pre-review

基準adc8bc4d。6実部品のgit showは7606ca9aの各ファイルとbyte一致6/6。§AH/AIと/tmp/frontend-raw-buttons-20260911/CARD-RAW-SHARED-RESUME-02.txt、退避SharedButtonMigration.test.tsxを読み取り照合。製品/正式文書/台帳変更なし、テスト実行なし。最終APPROVEは出さない。

## 修正を求める確定不備

SharedButtonMigration.test.tsx:145: vi.stubGlobal('URL', Object.assign(URL, ...))は元のURLコンストラクタ自身のcreateObjectURL/revokeObjectURLを置換する。afterEach:46のrestoreAllMocks/unstubAllGlobalsは、手作業で変更した元オブジェクト内の2プロパティを復元しない。このCSV試験後にmockが残る。元が提供するメソッドならvi.spyOnで復元可能なmockへ。元にないプロパティも扱う場合は元descriptorをtry/finallyで復元（存在しなかったならdelete）、または元を変更しない代替constructorでstubする。URL本体をObject.assignで直接変更しない。

## 後続証跡へ残す不足（現時点で製品不適合とはしない）

- Confirm autoFocusとModalのfocus移動の相互作用、Tab/ShiftTab、Enter/Space、ラベル/輪郭の画面内判定は当unitでは未検査。カード手順4の実before/afterブラウザーが必要。
- OrderFinancial/Purchase/Shippingの成功submitはexistingのPATCHのみ。新規recordでは確定/CSV無効だけを確認し、POST保存成功は未検査。既存属性/関数本文の構文一致と合わせて保持を判断し、POST保存まで動作実証済みとは書かない。
- new record試験:140はPATCHとfetchの未呼出しを確認するが、POSTが呼ばれない直接assertはない。disabled=true自体を確認しているため直ちに偽陽性とはしない。

## 現契約への整合

role5解除/再計算、保存中のdisabledと二度click防止、Priority権限なし、外部form IDとフォーム外のsubmit、exact URL/payload、onSaved/onClose、CSV token/Blob/revokeは実部品をmockせず確認する構成。翻訳mockはキー返却なので実言語の長文検証は別途必要。APIのcatch/finallyや不具合修正をこの便に増やす提案はしない。

## 再確認（修正版）

URL副作用の指摘は解消。:150のMockURL extends originalURLは自身のstatic2メソッドだけを定義し、元コンストラクタを変更しない。:52 afterEachでURL本体と元2メソッドの同一性を確認する。

Financial/Purchase/Shippingは既存PATCHと新規POSTの両方へ試験を拡張。Financial:108–120の未入力0/notes null/入力1250は本体buildPayload:147–155と一致。Purchase/Shipping:123–134の空値null/入力125.5又は2.5は本体の変換規則と一致。404モックで新規モードに入り、外部form属性/typeも検査。disabledの保存/キャンセルtrue、二度click送信追加0、完了時onSaved/onCloseを保持する試験構造。確認範囲の新たな不適合なし。

元の製品6ソースと試験1の確認時SHA256/行数をreviewed-hashes.jsonへ保存。この段階では試験実行結果・ブラウザー未完のため最終APPROVEは出さない。私は原稿と実ソースの読取照合のみ行い、試験は再実行していない。

## 初期ブラウザー原稿の中間確認

6部品before/after計12ファイルはimportのmodule参照先以外原物と一致。共有Modal/Button/CSS/token/実ja/enはadc8bc4dと一致。モックimport接続と非localhost通信abortあり。browser.mjsは6幅×明暗×日英×6部品の通常existing表示を対象とする。

残る原稿上の不足: measureのinside/focusSpaceは左右だけで、top/bottomの画面/Modal内を検査しない。labelInsideはボタン内部の上下を見るが親の縦clipを保証しない。実Modalヘッダーcloseにcomp-modal-close classはないので現除外filterは無効。期待DOM数/IDと移管対象を明示照合し、headerだけ等のevery空振りを防ぐ必要がある。測定は実focusではなく4px横余地だけであり、後続focus検査と区別する。

最長Confirm文言とキーボードは別原稿予定のため、この初期原稿に無いことだけで過剰拒否しない。試験再実行なし、最終判定なし。

## inventory診断の限定審査

DIAGNOSTIC_ONLYを維持。Commission failures0は初期表示の横欠けなしを意味しない。measureは各buttonへscrollIntoViewIfNeeded→focus→Tab→ShiftTabしてから読むため、各buttonで異なるscroll位置の個別到達可能性を表す。

実ログ: 英語commission-unassign-salesのcomp-modal-body.scrollLeftはbefore138/after147。旧scrollWidth528、新537は別browser-diagnostic-resultの実値。+9pxの横overflow増加をinventoryの到達後結果で否定できない。初期状態（scrollLeft0）と利用者のキー操作だけの状態、試験の強制scroll後を分けて評価する。

flags: inside=ボタンrectと祖先overflow矩形交差/viewportの四辺、fourPxInside=同rectを4px拡張、actualOutlineInside=outlineWidth+offset拡張、labelInside=文字rectがボタン内。failuresはこれら4boolだけ。active/focusVisibleは保存するがfailuresに含めていない（今回保存結果は全件true）。

クリップ推定は祖先border-box rectを交差するだけでclientLeft/clientTop/clientWidth/clientHeight、角丸/clip-path/maskは測っていない。したがって任意の実描画クリップの完全判定とは呼べない。現6部品に未知clipがあるとは断定しない。親の実画像/初期スクロール値/可視内容幅との突合が必要。

結論: 当inventory0件を根拠にCommissionの前提不足を解消済みとしたり、6部品一括の安全を証明したりできない。原測定を保持し、Commissionの表示前提は分離判断の対象に残す。製品編集/ブラウザー再実行なし。
