# Sol2 cross-review

**Verdict: REVISE**

## Product review

- APPROVE `frontend/src/pages/integrations/CarrierCredentialForm.tsx`: targets=1 migrated exact, inverse SHA-256 `50ff2a0db2459f990b9c48bbd816913da6e477a00a2e9c1d4f806a893c116ec8`
- APPROVE `frontend/src/pages/integrations/CarrierIntegrationPage.tsx`: targets=2 migrated exact, inverse SHA-256 `e174e54687dc2202f018dc7354ffca77ffc580f6a05d898874713945f4d23bab`
- APPROVE `frontend/src/pages/integrations/FedexEtdSetupGuide.tsx`: targets=1 migrated exact, inverse SHA-256 `8b342bf3bf133409403222ded31cb2211ccfa98a0791438b13facda10e4d82d4`
- APPROVE `frontend/src/pages/purchase-orders/PurchaseOrdersFormModal.tsx`: targets=1 migrated exact, inverse SHA-256 `680d951af798be84d6457fbce5fbb3c6d5d331a5e452f56aa6d7b791570ebe55`
- APPROVE `frontend/src/pages/purchase-orders/PurchaseOrdersPage.tsx`: targets=1 migrated exact, inverse SHA-256 `6a43185caca83c2e78137b9442d9575124af9e3bc2461e12d308e78e4f2ec0b5`
- APPROVE `frontend/src/pages/roles/RolesPage.tsx`: targets=1 migrated exact, inverse SHA-256 `809da1034f480b5d8321c5e25a25b5044a837a56b93f01a83f62f4dc108e4fd8`
- APPROVE `frontend/src/pages/super-admin/DexTab.tsx`: targets=3 migrated exact, inverse SHA-256 `895655551e1bc1cf7b2c7ec933b7839ab6ec14e09fc222ff496b451cab19a7e9`
- APPROVE `frontend/src/pages/super-admin/LLMBudgetTab.tsx`: targets=1 migrated exact, inverse SHA-256 `8a51b9c2344a9285d3d0b7274637548de6cb4f480f825b40fc9954e60618c7cc`
- APPROVE `frontend/src/pages/super-admin/TcgSeriesTab.tsx`: targets=2 migrated exact, inverse SHA-256 `a7a69efd7b8b01ee6c77bdb14523ff43931bbd6bfb9180da02149b606fcd6470`

Product result: 9 files / 13 targets APPROVE; raw=0, migrated=13, inverse=9/9. No product behavior/prop drift found.

## Test review

- `frontend/src/components/IntegrationLaunchButtonMigration.test.tsx` SHA-256 `fbcecccb8cbf729e9557e35c91ca719173f8bd6da6e6336879746947a917dd8b`
- `frontend/src/components/PurchaseAdminEditorButtonMigration.test.tsx` SHA-256 `14ba956521a5e64260712562251263f32c8d2232540e934e7bfff4a0240b9356`

### [MEDIUM] FedEx target does not prove its zero-write contract

`IntegrationLaunchButtonMigration.test.tsx` test “FedEx credentials step invokes its callback exactly once with zero writes” performs `mock.put.mockResolvedValue({})`, `mock.post.mockResolvedValue({})`, then clicks `saveAndTest` before reaching the target. It finally asserts only `mock.delete` is zero. Therefore the test title is false for the full test, and—more importantly—it never records PUT/POST counts immediately before the target click and proves they remain unchanged afterward. A regression where the migrated target also invokes PUT or POST would pass.

Required limited fix: after setup navigation completes, record `putBefore` and `postBefore`; click `fedexEtdGuideOpenCredentials`; assert callback exactly once and both PUT/POST counts equal their recorded baselines (plus DELETE remains zero). This preserves the real-component setup while proving the target-click delta is zero.

### Remaining test assessment

- Carrier cancel/open/edit/busy tests operate real controls, settle rejected deferred promises, and distinguish enabled/inert behavior.
- Purchase/admin suite covers all 9 targets with exact GET/write-count or populated-state assertions; pending purchase rejection is observed; no skip/todo/only found.
- No other missing callback assertion or unsettled deferred was found in these two files.

