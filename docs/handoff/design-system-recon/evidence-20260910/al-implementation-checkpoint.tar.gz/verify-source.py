from pathlib import Path
import subprocess,json,hashlib,re
r=Path('/Users/tanizawashingo/worktrees/salesanchor/release-frontend-fullpage-button-design');m=json.loads((r/'docs/handoff/design-system-recon/evidence-20260910/al-fullpage-button-audit.json').read_text());out=[]
for p in m['files']:
 s=(r/p['file']).read_text();old=subprocess.check_output(['git','show',m['base']+':'+p['file']],cwd=r,text=True);t=s.replace('import { Button } from "../../components/Button";\n','').replace('<Button','<button').replace('</Button>','</button>').replace('variant="secondary" size="md"','className="btn-secondary"').replace('variant="primary" size="md"','className="btn-primary"');assert t==old,p['file'];out.append({'file':p['file'],'sha256':hashlib.sha256(s.encode()).hexdigest(),'inverseExact':True})
Path(__file__).with_name('source-verification.json').write_text(json.dumps(out,indent=2));print('2 pages inverse byte equality: PASS')
