# Sol2 AT acceptance matrix

## AccountCompanySaveButtonMigration.test.tsx

- Profile exact seven-key payload, empty phone normalization, real `patchMyProfile`, pending disabled/duplicate click zero, real `UiPrefsProvider.refresh` GET increment, success UI: `uses the real UiPrefs refresh after the exact profile payload and blocks pending repeats`.
- Profile failure input retention, no early refresh, identical full-payload retry, success refresh/state: `retains profile input on failure and retries the full payload without refresh`.
- Company Basic initial dirty-disabled, required name zero-write, nonempty/empty fields, monthly frequency parse, monetary string preservation, exact 14-key payload, pending duplicate click zero, company+contacts reload, server state reset and clean-disabled: `submits the exact normalized company basic payload, blocks pending repeats and reloads`.
- Company Basic failure retention, no early reload, retry/success reload: `retains a failed company basic edit and retries without an early reload`.
- Channels exact three-separator normalization, failure retention/no reload, retry pending disabled/duplicate click zero, company+contacts reload, returned value and clean-disabled; settled permission denial hides both Save controls: `retains and retries failed channels, normalizes separators, and hides saves without update permission`.

## AdminMasterSaveButtonMigration.test.tsx

- PO two-item exact payload, pending Save/Cancel disabled and inert, ordered success callbacks: `PO exact payload blocks pending repeats and calls success callbacks in order`.
- PO missing supplier and supplier-with-invalid-item zero writes; failure keeps supplier/notes/item and callbacks zero; exact identical retry: `PO guards at zero writes and retains values for failure retry`.
- Dex pokemon exact full editValues PATCH, failure retention, retry, exact reload and editor close: `Dex saves exact pokemon fields, reloads, and retains values across failure retry`.
- Dex current pending behavior (unlocked/no aria-busy/two dispatches), both promises settled: `Dex keeps its unlocked repeated-submit behavior while pending and settles both writes`.
- Dex trainer schema/URL and exact reload: `Dex trainer edit sends the trainer schema and reloads its exact list`.
- TCG type exact normalized POST/reload/reset plus series edit exact six-key PATCH/reload/reset: `TCG type and series submits send exact normalized payloads and reload`.
- TCG series failure retention and current unlocked pending two dispatches, both settled, two exact reloads/reset: `TCG save failure retains inputs and pending remains unlocked for repeat writes`.
- TCG series native required zero write and exact six-key create POST/reload: `TCG required fields prevent writes and series create sends all normalized keys`.
- TCG type required zero write, failure retention and current unlocked pending exact call count, both settled, two type reloads/reset: `TCG type failure retains values and its pending save remains unlocked`.

## Evidence

- Final focused unit: `/tmp/at-sol2-validation/06-unit-final.log` — 2 files, 14 tests passed.
- Strict ESLint: `/tmp/at-sol2-validation/07-eslint-final.log` — exit 0, zero output.
- Product inverse audit: `/tmp/at-sol2-validation/08-inverse-audit.log` — 6/6 files, 7/7 targets.
- Diff check: `/tmp/at-sol2-validation/09-diff-check.log` — exit 0, zero output.
- Preserved initial failure: `/tmp/at-sol2-validation/01-unit-initial.log` — 4 failed / 6 passed; fixture causes corrected without product changes.
